import React from 'react'

export default function Future() {
  return (
    <h1>This page is in development!</h1>
  )
}
