# rideit_final
NOTE : - To run this project you need to have node modules package installed in your directory folder of the project.
To install node modules packages you can do following:-

1) npm create-react-app (name of app)
2) npm install node
3) npm install nodemon
4) npm install axiom
5) npm install react-router-dom
